<?php

$wphome = $_REQUEST['wphome'];
$wpurl = $_REQUEST['wpurl'];

error_reporting(0); // Set E_ALL for debuging

include_once dirname(__FILE__).DIRECTORY_SEPARATOR.'elFinderConnector.class.php';
include_once dirname(__FILE__).DIRECTORY_SEPARATOR.'elFinder.class.php';
include_once dirname(__FILE__).DIRECTORY_SEPARATOR.'elFinderVolumeDriver.class.php';
include_once dirname(__FILE__).DIRECTORY_SEPARATOR.'elFinderVolumeLocalFileSystem.class.php';

$opts = array('debug' => false);

$opts['roots'][] =
(
	array(
		'driver'        => 'LocalFileSystem',  
		'path'          => $wphome,
		'URL'           => $wpurl,
		'alias'         => "Fichiers du site",
        'quarantine'    => '.tmp'
	)
);
$connector = new elFinderConnector(new elFinder($opts));
$connector->run();
?>
