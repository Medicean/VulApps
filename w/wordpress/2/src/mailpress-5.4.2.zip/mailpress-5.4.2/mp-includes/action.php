<?php
//
include('../../../../wp-load.php');
//
include('../../../../wp-admin/includes/admin.php');
//
new MP_Actions();