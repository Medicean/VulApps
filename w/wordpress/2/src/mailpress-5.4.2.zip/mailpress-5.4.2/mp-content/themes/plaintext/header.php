<?php
echo get_option('blogname');
echo "\n";
echo get_option('blogdescription');
echo "\n\n";


