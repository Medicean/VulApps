<?php
/*
Template Name: weekly
*/

$this->get_template_part('_post');