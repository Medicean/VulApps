<?php /* nogent94 */
$_classes = array(

'button'		=> "	margin:0;
				color:#333;
				background-color:#fafafa;
				border-left:4px solid #D76716;
				border-right:4px solid #D76716;
				border-top:1px solid #590000;
				border-bottom:1px solid #590000;",

// header

'body'		=> "	color:#333;
				font-size:12px;
				line-height:18px;
				padding:20px;
				background:none repeat scroll 0 0 #d07b40; //d38249;
				vertical-align:baseline;
				font-family:Verdana,Geneva,Sans-Serif",

'wrapper'		=> "	margin:0 auto;
				border:none;
				padding:0 20px;
				width:700px;
				background:none repeat scroll 0 0 #FFF;",

'a'			=> "  color:#D76716;
				text-decoration:none;",

'333'			=> "	color:#333;",

);
?>