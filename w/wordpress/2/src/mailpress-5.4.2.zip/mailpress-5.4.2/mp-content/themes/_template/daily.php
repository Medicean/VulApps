<?php
/*
Template Name: daily
*/

$this->get_template_part('_post');