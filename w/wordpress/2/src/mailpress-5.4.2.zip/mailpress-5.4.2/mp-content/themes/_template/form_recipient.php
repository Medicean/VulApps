<?php
/*
Template Name: form_recipient
Subject: [<?php bloginfo('name');?>] Mail from form
*/

$this->build->_the_title = 'Mail from form';

$this->get_template_part('_mail');
