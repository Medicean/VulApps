<?php
/*
Template Name: form_visiteur
Subject: [<?php bloginfo('name');?>] Copie du formulaire
*/

$this->build->_the_title = "Copie du formulaire";

$this->get_template_part('_mail');