// mail
jQuery(document).ready(function(){ jQuery('#example').tabs(); });


