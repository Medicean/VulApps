<div class="doifdAdminHeader">
    <div class="doifdAdminText">
    <h2>DOIFD</h2>
    <p><?php echo apply_filters( 'doifd_admin_header', __( 'Double OPT-IN For Download - Free Version', 'double-opt-in-for-download' ) ) ?><?php echo ' ' . DOIFD::VERSION; ?><br /></p>
    <div id="fb-root"></div>
    <div class="fb-like-box" data-href="https://www.facebook.com/pages/Double-Opt-In-For-Download/371589009609336" data-colorscheme="dark" data-show-faces="false" data-header="false" data-stream="false" data-show-border="false"></div>
    </div>
    <div class="doifdAdminMisc">
        <div class="rateDOIFD">
        <img src="<?php echo DOIFD_ADMIN_IMG_URL; ?>rateit.jpg" ><br/>
        <a href="https://wordpress.org/plugins/double-opt-in-for-download/" target="new" />Rate DOIFD at Wordress.org</a></p>
        </div>
    </div>
</div>
