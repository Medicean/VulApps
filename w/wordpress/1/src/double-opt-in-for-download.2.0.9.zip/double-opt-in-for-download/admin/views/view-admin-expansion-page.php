<div class="wrap">
    <div class="doifdAdminLoader"></div>
    <?php include_once( DOIFD_DIR . 'admin/views/view-admin-header.php' ); ?>
    <h2>DOIFD Expansion Plugins</h2>
    <table>
        <tr>
            <td>
                <a href="http://www.doubleoptinfordownload.com/downloads/download-via-facebook/" target="_blank" /><img src="<?php echo DOIFD_ADMIN_IMG_URL ?>download-via-fb-icon.png" border="0" /></a>
            </td>
            <td>

            </td>
            <td>

            </td>
        </tr>
    </table>
</div>
