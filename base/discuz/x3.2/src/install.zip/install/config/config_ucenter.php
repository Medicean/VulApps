<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'discuz');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`discuz`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'FfT7s7ickb4bFeC4afMd5de9k7s59dv2f5U8Seufw5tfN4TaV5W8C0U54cz1Z1Qb');
define('UC_API', 'http://'.$_SERVER['HTTP_HOST'].'/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>