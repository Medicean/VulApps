<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 96fd2ebae88d13bfa6e09360eef8ca10

$pluginsetting = array (
);
?>