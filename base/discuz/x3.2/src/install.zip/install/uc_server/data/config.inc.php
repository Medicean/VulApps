<?php 
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'discuz');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', 'pre_ucenter_');
define('UC_COOKIEPATH', '/');
define('UC_COOKIEDOMAIN', '');
define('UC_DBCONNECT', 0);
define('UC_CHARSET', 'utf-8');
define('UC_FOUNDERPW', 'bdb4e8a7bc9277ab857d1a98366ca8c9');
define('UC_FOUNDERSALT', 'ufm7X7');
define('UC_KEY', '8fE727Dc6bMbXeK4Wfndida9r7x5wdL2x5d8deBfs5NfP4GaB538v0B52cD171eb');
define('UC_SITEID', 'rf27p7VcrbMbyei4Vf6dkdm9Z7i5nd72S588BeQfX5Kfy4War5z8b035ucL1A1jb');
define('UC_MYKEY', 'bfS757fc1bJbme14Yfwd1dU9K705Edy205483eFfP5zf94ma65M8N0C5ucL1P13b');
define('UC_DEBUG', false);
define('UC_PPP', 20);
